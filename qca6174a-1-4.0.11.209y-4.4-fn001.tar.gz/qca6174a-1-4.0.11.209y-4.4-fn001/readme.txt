
Release Note  
-----------------------------------------------
qca6174a-1-4.0.11.209y-4.4-fn001
-----------------------------------------------
Publisher: wayne@fn-link  Date:2017.12.19


1. Version 

	Chip: QCA6174-1
	Module: Fn-Link 8274x-PR
	OS: Linux / Android
	Kernel: 4.4.x/3.18x
	Driver: 4.0.11.209Y
	FW_VER: 2.0.0.187

2. Compile

	cd WLAN-AIO/build
	vi scripts/ra-f10/config.ra-f10  # Modify the kernel path and compile toolschain etc.
	make

3. Instructions

 a. Driver 
	WLAN-AIO/rootfs-ra-f10.build/lib/modules/wlan.ko
 b. firmware
	mv firmware/* /lib/firmware/ -Rf  # /lib/firmware is default firmware path,
					  #  you can change the path in driver according your platform 

 b. Load driver
	insmod cfg80211.ko      # From the kernel
	insmod wlan.ko
 c. wpa_supplicant
	WLAN-AIO/rootfs-ra-f10.build/sbin/wpa_supplicant




 
