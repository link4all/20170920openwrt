rt2860v2 driver package for OpenWrt
========

I got RT2860v2 v2.7.2.0 from RT-N56U Project on Google Code.

the package Makefile here: https://github.com/qdk0901/openwrt-mt7620

and something from OpenWrt PandoraBox: http://downloads.openwrt.org.cn/PandoraBox/

How to use this?
========
cd package && git clone https://github.com/981213/rt2860v2.git

  [*]   LED Support
  [*]   WSC (WiFi Simple Config)
  [*]     WSC 2.0 (WiFi Simple Config 2.0)
  [*]   LLTD (Link Layer Topology Discovery Protocol)
  [*]   WDS
  [*]   MBSSID
  [*]     New MBSSID mode
  [*]   AP-CLient Support
  [*]   Carrier Detection support
  [*]   Read and set MAC from MTD/EEPROM
  [*]   Provide ATE testmode commands support
  [*]     Provide QA tool support
