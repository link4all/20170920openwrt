rt2860v2 driver package for OpenWrt
========

I got the driver code here: https://github.com/wuqiong/rt2860v2-for-openwrt-mt7620
the package Makefile here: https://github.com/qdk0901/openwrt-mt7620
and something from OpenWrt PandoraBox: http://downloads.openwrt.org.cn/PandoraBox/

How to use this?
========
cd package && git clone https://github.com/981213/rt2860v2.git

  │ │    [*]     LED Support                                              │ │  
  │ │    [*]     WSC (WiFi Simple Config)                                 │ │  
  │ │    [*]       WSC 2.0(WiFi Simple Config 2.0)                        │ │  
  │ │    [*]     LLTD (Link Layer Topology Discovery Protocol)            │ │  
  │ │    [*]     WDS                                                      │ │  
  │ │    [ ]     WMM ACM                                                  │ │  
  │ │    [*]     MBSSID                                                   │ │  
  │ │    [*]       New MBSSID MODE                                        │ │  
  │ │    [*]     AP-CLient Support                                        │ │  
  │ │    [*]       MAC Repeater Support                                   │ │  
  │ │    [ ]     IGMP snooping                                            │ │  
  │ │    [ ]     NETIF Block                                              │ │  
  │ │    [ ]     DFS                                                      │ │  
  │ │    [*]     Carrier Detect                                           │ │  
  │ │    [ ]     DLS ((Direct-Link Setup) Support                         │ │  
  │ │    [ ]     IDS (Intrusion Detection System) Support                 │ │  
  │ │    [ ]     WAPI Support                                             │ │  
  │ │    [*]     CoC Support                                              │ │  
  │ │    [ ]     Memory Optimization                                      │ │  
  │ │    [ ]     Video Turbine support                                    │ │  
  │ │    [ ]     Extension Channel List                                   │ │  
  │ │    [ ]     Kernel Thread                                            │ │  
  │ │    [*]     Auto Channel Selection Enhancement                       │ │  
  │ │    [ ]     802.11n Draft3                                           │ │  
  │ │    [ ]     TSSI Compensation                                        │ │  
  │ │    [ ]     Adjust Power Consumption Support                         │ │  
  │ │    [ ]     Single SKU                                               │ │  
  │ │          Choose Power Design (Internal PA and Internal LNA)  --->   │ │  
  │ │    [ ]   TSSI Compensation                                          │ │  
  │ │    [ ]   Temperature Compensation                                   │ │  
  │ │    [ ]   802.11r Fast BSS Transition                                │ │  
  │ │    [ ]   802.11k Radio Resource Management                          │ │  
  │ │    [ ]   User specific tx rate of mcast pkt                         │ │  
  │ │    [ ]   Net-SNMP Support                                           │ │  
